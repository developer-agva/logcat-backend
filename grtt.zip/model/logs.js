// const mongoose = require("mongoose");

// const logsSchema = new mongoose.Schema(
//   {
//     deviceId:{
//       type:String, required:true, default:""
//     },
//     message: {
//       type: String, required:true, default:""
//     },
//     version:{
//       type:String, required:true
//     },
//     file: {
//       type: String, required:true, default:""
//     },
//     date:{
//       type:String, required:true,
//     }
//     // date: {
//     //   type: String,
//     //   required: [true, "Log date is required."],
//     //   default: Date.now()
//     // },
    
//     // filePath: {
//     //   type: String
//     // },
//   //   type: {
//   //     type: String,
//   //     default: "verbose",
//   //     enum: ["warn", "info", "error", "debug","verbose"],
//   //   },
//   },
//   { timestamps: true }
// );

// const logModel = mongoose.model("Log", logsSchema);

// module.exports = logsSchema;
