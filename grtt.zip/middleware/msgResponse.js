var deviceIdArr = [];


module.exports = {
    deviceIdArr,
}